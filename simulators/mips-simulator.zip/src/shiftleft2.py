from cpuElement import CPUElement
import unittest
from testElement import TestElement

class Shift2(CPUElement):
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)

        if len(inputSources) != 1:
            raise AssertionError(" left Shift2 has input")
        if len(outputValueNames) != 1:
            raise AssertionError(" left Shift2 has 1 output")
        if len(control) != 0:
            raise AssertionError(" left Shift2 has 0 control signal")
        if len(outputSignalNames) != 0:
            raise AssertionError(" left Shift2 has 0 control output")
        
        
        self.input1 = inputSources[0][1] # input
        
        self.output1 = outputValueNames[0]  # output
    
    def writeOutput(self):

      self.outputValues[self.output1] = self.inputValues[self.input1] << 2 


class TestShift2(unittest.TestCase):
    def setUp(self):
        self.shift2 = Shift2()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([],["address"],[],[])

        self.shift2.connect(
        [(self.testInput, "address")],["shiftedAddress"],[],[])

        self.testOutput.connect(
        [(self.shift2, "shiftedAddress")],[],[],[])

    def test_behavior(self):
        self.testInput.setOutputValue("address", 0x2)

        self.shift2.readInput()
        self.shift2.writeOutput()
        self.testOutput.readInput()

        if self.testOutput.inputValues["shiftedAddress"] != 0x8:
            raise AssertionError("Expected 8")


if __name__ == '__main__':
    unittest.main()