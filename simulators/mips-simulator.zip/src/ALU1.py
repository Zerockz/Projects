import unittest
from cpuElement import CPUElement
import common
from testElement import TestElement

class Alu(CPUElement):  

    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)
        self.memory = []
        assert(len(inputSources) == 2), "alu should have 2 inputs"
        assert(len(outputValueNames) == 1), "alu has only 1 output"
        assert(len(control) == 1), "alu has one control signal"
        assert(len(outputSignalNames) == 1), "alu does  have  control output"

        self.inputZero = inputSources[0][1] # data1 
        self.inputOne = inputSources[1][1]  # data2 
      
        self.outputNameone = outputSignalNames[0]  # zerodata 1 control signal

        self.outputNametwo = outputValueNames[0]   # output data 2

        self.controlName = control[0][1]   # alu contol signal 4 bit

    def writeOutput(self):
        alu_control = self.controlSignals[self.controlName]  # 4-bit control signal from main control unit
        
        assert isinstance(alu_control, int) and not isinstance(alu_control, bool), "Invalid ALU control signal"

        if alu_control == 0:  # AND
            result = self.inputValues[self.inputZero] & self.inputValues[self.inputOne]
            zero_flag = 0

        elif alu_control == 1:  # OR
            result = self.inputValues[self.inputZero] | self.inputValues[self.inputOne]
            zero_flag = 0

        elif alu_control == 2:  # ADD
            result = self.inputValues[self.inputZero] + self.inputValues[self.inputOne]
            zero_flag = 0

        elif alu_control == 3:  # ADD unsigned
            result = ((self.inputValues[self.inputZero] & 0xffffffff) + (self.inputValues[self.inputOne] & 0xffffffff)) & 0xffffffff
            zero_flag = 0

        elif alu_control == 6:  # SUBTRACT
            result = self.inputValues[self.inputZero] - self.inputValues[self.inputOne]
            zero_flag = 1 if result == 0 else 0

        elif alu_control == 7:  # SET LESS THAN
            result = 1 if self.inputValues[self.inputZero] < self.inputValues[self.inputOne] else 0
            zero_flag = 0

        elif alu_control == 8:  # SUBTRACT unsigned
            result = ((self.inputValues[self.inputZero] & 0xffffffff) - (self.inputValues[self.inputOne] & 0xffffffff))
            zero_flag = 1 if result == 0 else 0

        elif alu_control == 9:  # ADD immediate
            result = self.inputValues[self.inputZero] + self.inputValues[self.inputOne]
            zero_flag = 0

        elif alu_control == 10:  # ADD immediate unsigned
            result = ((self.inputValues[self.inputZero] & 0xffffffff) + (self.inputValues[self.inputOne] & 0xffffffff)) & 0xffffffff
            zero_flag = 0

        elif alu_control == 11:  # LOAD upper immediate
            result = self.inputValues[self.inputOne] << 16
            zero_flag = 0

        elif alu_control == 12:  # BRANCH if equal
            result = 1 if self.inputValues[self.inputZero] == self.inputValues[self.inputOne] else 0
            zero_flag = 0

        elif alu_control == 18:  # BRANCH if not equal
            result = 1 if self.inputValues[self.inputZero] != self.inputValues[self.inputOne] else 0
            zero_flag = 0

        elif alu_control == 14:  # JUMP
            result = self.inputValues[self.inputOne]
            zero_flag = 0



        elif alu_control == 15:  # LOAD word
                address = (self.inputValues[self.inputOne] + self.inputValues[self.inputZero]) // 4
                result = self.memory[address]
                zero_flag = 0

        elif alu_control == 16:  # STORE word
                address = (self.inputValues[self.inputOne] + self.inputValues[self.inputZero]) // 4
                self.memory[address] = self.inputValues[self.inputZero]
                result = self.inputValues[self.inputZero]
                zero_flag = 0



        elif alu_control == 17:  # NOR
            result = ~(self.inputValues[self.inputZero] | self.inputValues[self.inputOne]) & 0xffffffff
            zero_flag = 0

        elif alu_control == 13:  # BREAK
            raise SystemExit("Break executed")

        else:
            raise ValueError(f"Wrong control signal: {alu_control}")

        self.outputValues[self.outputNametwo] = result
        self.outputControlSignals[self.outputNameone] = zero_flag






class TestAlu(unittest.TestCase):
    def setUp(self):
        self.alu_test = Alu()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([], ["input_one", "input_two"], [], ["input_control_signal"])
        self.alu_test.connect([(self.testInput, "input_one"), (self.testInput, "input_two")], ["alu_result_data"], [(self.testInput, "input_control_signal")], ["alu_result_zero"])
        self.testOutput.connect([(self.alu_test, "alu_result_data")], [], [(self.alu_test, "alu_result_zero")], [])

    def run_alu_test(self, input_one, input_two, control_signal, expected_data, expected_zero):
        self.testInput.setOutputValue("input_one", input_one)
        self.testInput.setOutputValue("input_two", input_two)
        self.testInput.setOutputControl("input_control_signal", control_signal)

        self.alu_test.readInput()
        self.alu_test.readControlSignals()
        self.alu_test.writeOutput()

        self.testOutput.readInput()
        self.testOutput.readControlSignals()

        output_data = self.testOutput.inputValues["alu_result_data"]
        output_zero = self.testOutput.controlSignals["alu_result_zero"]

        self.assertEqual(output_data, expected_data)
        self.assertEqual(output_zero, expected_zero)

    def test_correct_behavior(self):
        self.run_alu_test(54, 54, 2, 108, 0)  # ADD
        self.run_alu_test(54, 54, 3, 108, 0)  # ADD unsigned
        self.run_alu_test(42, 4, 14, 4, 0)   # STORE word 
        self.run_alu_test(54, 54, 6, 0, 1)    # SUBTRACT
        self.run_alu_test(24, 24, 8, 0, 1)    # SUBTRACT unsigned
        self.run_alu_test(3, 2, 0, 2, 0)      # AND
        self.run_alu_test(3, 2, 1, 3, 0)      # OR
        self.run_alu_test(3, 2, 17, 0xfffffffc, 0)  # NOR
        self.run_alu_test(3, 2, 9, 5, 0)      # ADD immediate
        self.run_alu_test(3, 2, 10, 5, 0)     # ADD immediate unsigned
        self.run_alu_test(0, 1, 11, 65536, 0) # LOAD upper immediate
        self.run_alu_test(3, 3, 12, 1, 0)     # BRANCH if equal
        self.run_alu_test(3, 2, 18, 1, 0)     # BRANCH if not equal
        self.run_alu_test(3, 2, 14, 2, 0)     # JUMP
        self.alu_test.memory = "hello"          # Initialize memory for LW test
        self.run_alu_test(1, 1, 15, "h", 0)    # LOAD word 
        self.run_alu_test(3, 5, 7, 1, 0)      # SET LESS THAN 




        with self.assertRaises(SystemExit):   # BREAK
            self.run_alu_test(0, 0, 13, 0, 0)

if __name__ == '__main__':
    unittest.main()
