'''
Implements CPU element for Instruction Memory in MEM stage.

Code written for inf-2200, University of Tromso
'''
import sys
import unittest
from testElement import TestElement

from cpuElement import CPUElement
from memory import Memory

class InstructionMemory(Memory):
    def __init__(self, filename):
        Memory.__init__(self, filename)
    
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)
        
        if len(inputSources) !=1:
            raise AssertionError("The input should only be 1")
        if len(outputValueNames) !=7:
            raise AssertionError("There are only 7 outputs")
        if len(control) !=0:
            raise AssertionError("IM has no control")
        if len(outputSignalNames) !=0:
            raise AssertionError("there are 0 control output signals")
        
        self.read= inputSources[0][1] #reads from PC


        self.output1= outputValueNames[0] #jump

        self.output2= outputValueNames[1] # opcode
        self.output3= outputValueNames[2] # reads register 1
        self.output4= outputValueNames[3] #reads register 2
        self.output5= outputValueNames[4] #mux
        self.output6= outputValueNames[5] # sign extend
        self.output7= outputValueNames[6] # ALU control





          
        
    
    def writeOutput(self):
        
        address= self.inputValues[self.read]
        code= self.memory[address]

        if code==13: # if break detected exit
            sys.exit
 


        self.outputValues[self.output1]= code >> 26 # opcode
        self.outputValues[self.output2]= (code >> 21)& 0x1F # 25:21 read reg
        self.outputValues[self.output3] = (code >> 16) & 0x1F # 20:16 read reg
        self.outputValues[self.output4] = (code >> 11) & 0x1F # 15:11 write reg
        self.outputValues[self.output5] = code & 0xFFFF  # 15:0  sign extend 16 bit
        self.outputValues[self.output6] = code & 0x3F  # 5:0  funct to ALU  
        self.outputValues[self.output7]= code & 0x3FFFFFF #25:0 jump























class TestInstructionMemory(unittest.TestCase):
    def setUp(self):
        self.instructionmemory = InstructionMemory("add.mem")
        self.testInput=TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([],["input"],[],[])

        self.instructionmemory.connect(
            [(self.testInput, "input")],["opcode", "read1", "read2", "write1", "signextend", "alucontrol", "jump"],[],[])

        self.testOutput.connect(
            [(self.instructionmemory, "opcode"), (self.instructionmemory, "read1"), (self.instructionmemory, "read2"),
             (self.instructionmemory, "write1"), (self.instructionmemory, "signextend"), (self.instructionmemory, "alucontrol"),
             (self.instructionmemory, "jump")],[],[],[])

    def test_behavior(self):
        # Set the input value
        self.testInput.setOutputValue("input", 0xbfc00210)

        # Read input and write output
        self.instructionmemory.readInput()
        self.instructionmemory.writeOutput()

        # Read the output values
        self.testOutput.readInput()


    
        # Expected values based of 0xbfc00210 (0x01495020)
        
        expected_opcode_value = 0  # Opcode
        expected_read1_value = 10  # $t1 register 
        expected_read2_value = 9  # $t2 register 
        expected_write1_value = 10  # $t2 register (end)
        expected_signextend_value = 0 
        expected_alucontrol_value = 32  # functcode
        expected_jump_value = 0

        read2 = self.testOutput.inputValues["read2"]
        

        if read2 != expected_read2_value:
            raise AssertionError(f"expected: {expected_read2_value}, instead got: {read2}")        

if __name__ == '__main__':
    unittest.main()

