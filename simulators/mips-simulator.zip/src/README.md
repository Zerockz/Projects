To run the code you use: >python3 simulator.py <insert.mem file>
