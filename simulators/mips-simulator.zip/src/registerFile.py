'''
Code written for inf-2200, University of Tromso
'''

import unittest
from cpuElement import CPUElement
import common
from testElement import TestElement


class RegisterFile(CPUElement):
    def __init__(self):
        # Dictionary mapping register number to register value
        self.register = {}
        # Note that we won't actually use all the registers listed here...
        self.registerNames = ['$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
                              '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
                              '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
                              '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra']
        # All registers default to 0
        for i in range(0, 32):
            self.register[i] = 0

    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources,
                           outputValueNames, control, outputSignalNames)

        if len(inputSources) != 4:
            raise AssertionError("There are only 4 inputs")
        if len(outputValueNames) != 2:
            raise AssertionError("There are only 2 outputs")
        if len(control) != 1:
            raise AssertionError("There is only 1 control signal")
        if len(outputSignalNames) != 0:
            raise AssertionError("There are no control outputs")
        
        
        self.input1= inputSources[0][1] #read reg 1
        self.input2= inputSources[1][1] #read reg2
        self.input3= inputSources[2][1] #write reg
        self.input4= inputSources[3][1] #write data

        self.output1= outputValueNames[0] #read data 1
        self.output2= outputValueNames[1] #read data 2

        self.control1= control[0][1] #control signal 
        

    def writeOutput(self):
        Controlreg = self.controlSignals[self.control1]

        if not isinstance(Controlreg, int):
            raise TypeError("Controlreg must be an int")

        number = self.inputValues[self.input1]  # Reg num for first read
        self.outputValues[self.output1] = self.register[number]  # Read from first reg

        number2 = self.inputValues[self.input2]  # Register num for second read
        self.outputValues[self.output2] = self.register[number2]  # Read from second reg

        if Controlreg:
            writeregnum = self.inputValues[self.input3]  # Reg num for writing
            self.register[writeregnum] = self.inputValues[self.input4]  # Write to write reg





    def printAll(self):
        '''
        Print the name and value in each register.
        '''

        print()
        print("Register file")
        print("================")
        for i in range(0, 32):
            print("%s \t=> %s (%s)" % (self.registerNames[i], common.fromUnsignedWordToSignedWord(
                self.register[i]), hex(int(self.register[i]))[:-1]))
        print("================")
        print()
        print()

class TestRegisterFile(unittest.TestCase):
    
    def setUp(self):
        self.registerfile = RegisterFile()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([],["read_reg1", "read_reg2", "write_reg1", "write_data1"],[],["reg_write_control"])

        self.registerfile.connect([(self.testInput, "read_reg1"), (self.testInput, "read_reg2"), (self.testInput, "write_reg1"), (self.testInput, "write_data1")],["read_data1", "read_data2"],[(self.testInput, "reg_write_control")],[])

        self.testOutput.connect([(self.registerfile, "read_data1"), (self.registerfile, "read_data2")],[],[],[])

    def test_initialization(self):
        # Test that all registers are initialized to 0
        for i in range(32):
            self.assertEqual(self.registerfile.register[i], 0)

    def test_correct_behavior(self):
        self.testInput.setOutputControl("reg_write_control", True)
        self.testInput.setOutputValue("write_reg1", 1)
        self.testInput.setOutputValue("write_data1", 300)
      

        self.registerfile.readInput()
        self.registerfile.readControlSignals()
        self.registerfile.writeOutput()
        self.testOutput.readInput()
      

        #self.registerfile.printAll()
        
        if self.registerfile.register[1] !=300:
            raise AssertionError(f"expected 300 got {self.registerfile.register[1]}")




if __name__ == '__main__':
    unittest.main()
