from cpuElement import CPUElement
import unittest
from testElement import TestElement

class Shift16(CPUElement):
  
    
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)


        if len(inputSources) != 1:
            raise AssertionError(" shift 16 has 1 input")
        if len(outputValueNames) != 1:
            raise AssertionError(" shift 16 has 1 output")
        if len(control) != 0:
            raise AssertionError(" shift 16 has 0 control signal")
        if len(outputSignalNames) != 0:
            raise AssertionError(" shift 16 has 0 control output")
        

        self.input1 = inputSources[0][1] # input
        
        self.output1 = outputValueNames[0]  # output
       

        
      
    
    def writeOutput(self):
       

      self.outputValues[self.output1] = self.inputValues[self.input1] << 16


class TestShift16(unittest.TestCase):
    def setUp(self):
        self.testInput = TestElement()
        self.testOutput = TestElement()
        self.shift16 = Shift16()

        self.testInput.connect([], ["inputaddress"], [], [])
        self.shift16.connect([(self.testInput, "inputaddress")], ["shifted_output"], [], [])
        self.testOutput.connect([(self.shift16, "shifted_output")], [], [], [])

    def test_behaviour(self):
        test_cases = [
            (1, 65536),
            (0, 0),
            (2, 131072),
  
        ]

        for input_value, expected_output in test_cases:
            with self.subTest(input_value=input_value, expected_output=expected_output):
                self.testInput.setOutputValue("inputaddress", input_value)
                self.shift16.readInput()
                self.shift16.writeOutput()
                self.testOutput.readInput()

                output = self.testOutput.inputValues["shifted_output"]
                if output!= expected_output:
                    raise AssertionError(f"expected : {expected_output}, got : {output}")
                

if __name__ == '__main__':
    unittest.main()