'''
Implements base class for memory elements.

Note that since both DataMemory and InstructionMemory are subclasses of the Memory
class, they will read the same memory file containing both instructions and data
memory initially, but the two memory elements are treated separately, each with its
own, isolated copy of the data from the memory file.

Code written for inf-2200, University of Tromso
'''

from cpuElement import CPUElement
import common
import sys

class Memory(CPUElement):
    def __init__(self, filename):
    
        # Dictionary mapping memory addresses to data
        # Both key and value must be of type 'long'
        self.memory = {}
        
        self.initializeMemory(filename)
    
    def initializeMemory(self, filename):
        '''
        Helper function that initializes the data memory by reading input
        data from a file.
        '''
        with open(filename, "r") as file:
            for row in file:
                if row and row[0] not in ['#', '>', '\n']:
                    part = row.split()
                    if len(part) >= 2:  # Ensure there are 2 parts
                        address = int(part[0], 16)
                        value = int(part[1], 16)
                        self.memory[address] = value






    def printAll(self):
        for key in sorted(self.memory.keys()):
            print("%s\t=> %s\t(%s)" % (hex(int(key)), common.fromUnsignedWordToSignedWord(self.memory[key]), hex(int(self.memory[key]))))



if __name__ == '__main__':
    
    if len(sys.argv) != 2:
        print("ERROR: ONLY 2 ARGUMENTS")
        sys.exit(1)
    
    memoryFile = sys.argv[1]

    memory = Memory(memoryFile)

    memory.printAll()
