from cpuElement import CPUElement
from memory import Memory
import unittest
from testElement import TestElement

class Altershift(CPUElement):
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)

        if len(inputSources) != 2:
            raise AssertionError(" altershift has 2 input")
        if len(outputValueNames) != 1:
            raise AssertionError(" altershift has 1 output")
        if len(control) != 0:
            raise AssertionError(" altershift has 0 control signal")
        if len(outputSignalNames) != 0:
            raise AssertionError(" altershift has 0 control output")
        
        self.input1 = inputSources[0][1] # input instruct 25:0
        self.input2 = inputSources[1][1] # input adder 31:0
        self.output1 = outputValueNames[0] # 31:28 26 bits left shifted by 2

    
    

    def writeOutput(self):
        lsbits = self.inputValues[self.input1] << 2  # left shifted bits
        topfour = self.inputValues[self.input2] & 0xf0000000  #4 most significant bits
        self.outputValues[self.output1] = lsbits + topfour  # 32 bit jump address



class TestAltershift(unittest.TestCase):
    def setUp(self):
        self.altershift = Altershift()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([], ["input1", "input2"], [], [])
        self.altershift.connect([(self.testInput, "input1"), (self.testInput, "input2")], ["data_result"], [], [])
        self.testOutput.connect([(self.altershift, "data_result")], [], [], [])

    def test_correct_behavior(self):
        test_cases = [
            (0x3f00080, 0xbfc00004, 0xbfc00200),
            (0x00000000, 0x00000000, 0x00000000),
            
        ]

        for input1, input2, expected_output in test_cases:
            with self.subTest(input1=input1, input2=input2, expected_output=expected_output):
                self.testInput.setOutputValue("input1", input1)
                self.testInput.setOutputValue("input2", input2)

                self.altershift.readInput()
                self.altershift.writeOutput()
                self.testOutput.readInput()

                output_data = self.testOutput.inputValues["data_result"]
                if output_data!= expected_output:
                    raise AssertionError(f"expected : {expected_output}, got : {output_data}")
                

if __name__ == '__main__':
    unittest.main()