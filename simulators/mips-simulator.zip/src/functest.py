'''
Code written for inf-2200, University of Tromso
'''

import unittest

# Import elements with tests
from mux import *
from registerFile import *
from testCommon import *
from instructionMemory import *
from dataMemory import*
from shiftleft2 import*
from shift16 import*
from Signextend import*
from ALU1 import*
from control import*
from alterand import*
from altershift import*


if __name__ == '__main__':
    unittest.main() # Run all tests
