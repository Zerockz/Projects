from cpuElement import CPUElement
from memory import Memory
import unittest
from testElement import TestElement

class Alterand(CPUElement):
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)

        if len(inputSources) != 0:
            raise AssertionError(" alterand has 0 input")
        if len(outputValueNames) != 0:
            raise AssertionError(" alterand has 0 output")
        if len(control) != 3:
            raise AssertionError(" alterand has 3 control signal")
        if len(outputSignalNames) != 1:
            raise AssertionError(" alterand has 1 control output")

        self.input1 = control[0][1] # branch control
        self.input2 = control[1][1] # branch not equal
        self.input3 = control[2][1] # zero input from alu
        self.output1 = outputSignalNames[0] # output branch signal
       
    
    def writeOutput(self):
    
    

        if (self.controlSignals[self.input1] == 1 and self.controlSignals[self.input3] == 1) or (self.controlSignals[self.input2] == 1 and self.controlSignals[self.input3] == 0):
            self.outputControlSignals[self.output1] = 1
        else:
            self.outputControlSignals[self.output1] = 0

class TestAlterand(unittest.TestCase):
    def setUp(self):
        self.alterand = Alterand()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([], [], [], ["branche", "branchne", "zero_flag"])
        self.alterand.connect([], [], [(self.testInput, "branche"), (self.testInput, "branchne"), (self.testInput, "zero_flag")], ["result_signal"])
        self.testOutput.connect([], [], [(self.alterand, "result_signal")], [])

    def test_correct_behavior(self):
        test_cases = [
            (1, 0, 0, 0),
            (1, 0, 1, 1),
            (0, 1, 0, 1),
        ]

        for branche, branchne, zero_flag, expected_output in test_cases:
            with self.subTest(branche=branche, branchne=branchne, zero_flag=zero_flag, expected_output=expected_output):
                self.testInput.setOutputControl("branche", branche)
                self.testInput.setOutputControl("branchne", branchne)
                self.testInput.setOutputControl("zero_flag", zero_flag)

                self.alterand.readInput()
                self.alterand.readControlSignals()
                self.alterand.writeOutput()
                self.testOutput.readControlSignals()

                output = self.testOutput.controlSignals["result_signal"]
                if output != expected_output:
                    raise AssertionError(f"expected {expected_output} not {output}")
                self.assertEqual(output, expected_output)


if __name__ == '__main__':
    unittest.main()