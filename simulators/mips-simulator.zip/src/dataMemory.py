'''
Implements CPU element for Data Memory in MEM stage.

Code written for inf-2200, University of Tromso
'''

from cpuElement import CPUElement
from memory import Memory
import common
import unittest
from testElement import TestElement

class DataMemory(Memory):
    def __init__(self, filename):
        Memory.__init__(self, filename)
        
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)
        
        if len(inputSources) !=2:
            raise AssertionError("DataMemory only has 2 inputs")
        if len(outputValueNames)!=1:
            raise AssertionError("Datamemory only has 1 output")
        if len(control)!=2:
            raise AssertionError("Datamemory has 2 control signals")
        if len(outputSignalNames)!=0:
            raise AssertionError("Theres no control output for datamemory")

      
        self.input1 = inputSources[0][1] # address
        self.input2= inputSources[1][1]  # write data
        self.output1 = outputValueNames[0]  # read data
        self.control2 = control[1][1]   # memread 
        self.control1 = control[0][1]   # memwrite
    
    def writeOutput(self):

        address = self.inputValues[self.input1] 
        
        if self.controlSignals[self.control1]:
             self.memory[address] =  self.inputValues[self.input2] #32 bit item stored if memwrite

        if self.controlSignals[self.control2]:
             self.outputValues[self.output1] = self.memory.get(address,0) #32 bit read if memread
       
   


    


class TestDataMemory(unittest.TestCase):
    def setUp(self):
        self.datamemory = DataMemory("add.mem")
        self.testInput = TestElement()
        self.testOutput = TestElement()


        self.testInput.connect([],["input","writedata"],[],["memwrite", "memread"])

        self.datamemory.connect(
        [(self.testInput, "input"), (self.testInput, "writedata")],["datamem_output"],[(self.testInput, "memwrite"), (self.testInput, "memread")],[])

        self.testOutput.connect(
        [(self.datamemory, "datamem_output")],[],[],[])


    def saver(self):
        self.datamemory.readInput()
        self.datamemory.readControlSignals()
        self.datamemory.writeOutput()
        self.testOutput.readInput()



    def test_behaviour(self):
        self.testInput.setOutputValue("input", 0x00408)
        self.testInput.setOutputValue("writedata", 50)

        self.datamemory.memory[0x00408] = 10

        self.testInput.setOutputControl("memread", True)
        self.testInput.setOutputControl("memwrite", False)

        self.saver()


        output = self.testOutput.inputValues["datamem_output"]
        if output != 10:
            raise AssertionError(f"expected 19 not {output}")

        self.testInput.setOutputControl("memwrite", True)
        self.testInput.setOutputControl("memread", False)

        self.saver()

        self.testInput.setOutputControl("memread", True)
        self.testInput.setOutputControl("memwrite", False)

        self.saver()

        output = self.testOutput.inputValues["datamem_output"]
        if output!=50:
            raise AssertionError(f"expected 20 got: {output}")
 








if __name__ == '__main__':
    unittest.main()



        
        
        



    
