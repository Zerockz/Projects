from cpuElement import CPUElement
import unittest
from testElement import TestElement


class SignExtend(CPUElement):
    
    
    def connect(self, inputSources, outputValueNames, control, outputSignalNames):
        CPUElement.connect(self, inputSources, outputValueNames, control, outputSignalNames)

        if len(inputSources) != 1:
            raise AssertionError(" Signextend has input")
        if len(outputValueNames) != 1:
            raise AssertionError(" Signextend has 1 output")
        if len(control) != 0:
            raise AssertionError(" Signextend has 0 control signal")
        if len(outputSignalNames) != 0:
            raise AssertionError(" Signextend has 0 control output")
       

        self.input1 = inputSources[0][1] #"input "
        
        self.output1 = outputValueNames[0] #"output "
       

        
     
    def writeOutput(self):
        input_value = self.inputValues[self.input1]  # Read the input value
        sign_bit = (input_value >> 15) & 1  # Extract the sign bit
        
        if sign_bit:
            extended_value = input_value | 0xFFFF0000  # Sign extend by setting upper bits to 1
        else:
            extended_value = input_value & 0x0000FFFF  # Zero extend by setting upper bits to 0
        
        self.outputValues[self.output1] = extended_value  # Write extended value tooutput




class TestAltershift(unittest.TestCase):
    def setUp(self):
        self.signextend = SignExtend()
        self.testInput = TestElement()
        self.testOutput = TestElement()

        self.testInput.connect([],["input_one"],[],[])

        self.signextend.connect([(self.testInput, "input_one")],["result_data"],[],[])

        self.testOutput.connect([(self.signextend, "result_data")],[],[],[])


    def test_behavior(self):
        self.testInput.setOutputValue("input_one", 123)
      
       

        self.signextend.readInput()
        self.signextend.writeOutput()
        self.testOutput.readInput()
   

        if self.testOutput.inputValues["result_data"] != 123:
            raise AssertionError("expected 123")
    
    
        


if __name__ == '__main__':
    unittest.main() 

