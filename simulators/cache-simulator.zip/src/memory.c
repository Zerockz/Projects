
#include "memory.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


// Cache parameters

#define L1_instruction_size 32
#define l1_data_size 32

#define l1_data_blocksize 64
#define L1_instruction_blocksize 64

#define L1_instruction_associativity 4
#define L1_instruction_policy 1
#define l1_data_associativity 4
#define l1_data_policy 1

#define l2_size 256
#define l2_blocksize 64
#define l2_associativity 4
#define l2_policy 1


// Typedef-ing structures
typedef struct cache cache_t;
typedef struct info info_t;

// Global variables representing each cache structure
static cache_t *cache_one_intruction, *cache_one_data, *cache_two;

// Structure for each cache block

struct info {
  uint64_t index;
  uint64_t LRU;
  uint64_t valid;
  uint64_t descriptor;
  uint64_t modified_bit;
};

// Structure for each cache
struct cache{
  info_t **array;
  uint64_t size;
  uint64_t blocksize;
  uint64_t index_sets;
  uint64_t descriptor_bitsize;
  uint64_t index_bitsize;
  uint64_t offset_bitsize;
  int associativity;
  uint64_t hit;
  uint64_t miss;
  int policy;
  cache_t *next;
};



// Instruction counter
static uint64_t instruction_count;



/*
 * Create a cache with given cache-size(kb), block size (B), associativity(int), policy(int)
 */

static cache_t *cache_create(uint64_t size, uint64_t block_size, int associativity, int policy) {
    // Allocate memory for cache structure
    cache_t *cache = malloc(sizeof(cache_t));
    if (cache == NULL) {
        return NULL;
    }

    // Calculate cache parameters
    uint64_t size_two = size * 128;
    uint64_t index_size = size_two / (block_size * associativity);
    uint64_t index_bits = log2(index_size);
    uint64_t offset_bits = log2(block_size);
    
    // Initialize cache structure
    cache->hit = 0;
    cache->miss = 0;
    cache->size = size_two;
    cache->index_sets = index_size;
    cache->index_bitsize = index_bits;
    cache->descriptor_bitsize = 32 - index_bits - offset_bits;
    cache->policy = policy;
    cache->blocksize = block_size;
    cache->associativity = associativity;
    cache->offset_bitsize = offset_bits;
    

    // Allocate memory for the array of pointers
    cache->array = calloc(index_size * associativity, sizeof(info_t *));
    if (cache->array == NULL) {
        free(cache);
        return NULL;
    }

    // Allocate and initialize memory for each array element
    for (int i = 0; i < index_size * associativity; i++) {
        cache->array[i] = malloc(sizeof(info_t));
        if (cache->array[i] == NULL) {
            // Free previously allocated memory in case of failure
            for (int j = 0; j < i; j++) {
                free(cache->array[j]);
            }
            free(cache->array);
            free(cache);
            return NULL;
        }
        cache->array[i]->index = 0;
        cache->array[i]->modified_bit = 0;
        cache->array[i]->LRU = 0;
        cache->array[i]->valid = 0;
        cache->array[i]->descriptor = 0;
        
    }

    return cache;
}



// Set up index values and LRU values 
// for all elements in the array
// Set up index values and LRU values for all elements in the cache

static void set_index_LRU(cache_t *cache) {
    if (cache == NULL || cache->array == NULL) {
        return; // Handle null cache or array
    }

    int total_elements = cache->index_sets * cache->associativity;

    for (int i = 0; i < total_elements; i++) {
        int index = i / cache->associativity;
        int LRU = i % cache->associativity;

        cache->array[i]->LRU = LRU;
        cache->array[i]->index = index;
    }
}



// Initializing memory subsystem
void memory_init(void) {
    // Allocate memory for the three caches and set up the index values
    cache_two = cache_create(l2_size, l2_blocksize, l2_associativity, l2_policy);
    if (cache_two != NULL) {
        set_index_LRU(cache_two);
        cache_two->next = NULL;
    }

    cache_one_intruction = cache_create(L1_instruction_size, L1_instruction_blocksize, L1_instruction_associativity, L1_instruction_policy);
    if (cache_one_intruction != NULL) {
        set_index_LRU(cache_one_intruction);
        cache_one_intruction->next = cache_two;
    }

    cache_one_data = cache_create(l1_data_size, l1_data_blocksize, l1_data_associativity, l1_data_policy);
    if (cache_one_data != NULL) {
        set_index_LRU(cache_one_data);
        cache_one_data->next = cache_two;
    }

    // Set instruction_counter to 0
    instruction_count = 0;
}







/*
 * Function for write-operation for write through
 */

static void cache_wt_write(cache_t *cache, uint64_t address) {
    // Calculate index and descriptor from the address
    uint64_t addr_index = (address >> cache->offset_bitsize) & ((1 << cache->index_bitsize) - 1);
    uint64_t addr_descriptor = address >> (cache->offset_bitsize + cache->index_bitsize);

    // Calculate the start and end of the set
    int set_start = addr_index * cache->associativity;
    int set_end = set_start + cache->associativity;

    // Find the least recently used (LRU) line in the set
    int lru_index = set_start;
    for (int i = set_start; i < set_end; i++) {
        if (cache->array[i]->LRU == cache->associativity - 1) {
            lru_index = i;
            break;
        }
    }

    // Update the cache line with the new address
    cache->array[lru_index]->descriptor = addr_descriptor;  
    cache->array[lru_index]->modified_bit = 1;
    cache->array[lru_index]->valid = 1;
    // Write the data to the next cache if there is one
    if (cache->next != NULL) {
        uint64_t new_address = (addr_descriptor << (cache->index_bitsize + cache->offset_bitsize)) |
                               (addr_index << cache->offset_bitsize);
        cache_wt_write(cache->next, new_address);
    }

    // Update all the LRU values in the set
    for (int i = set_start; i < set_end; i++) {
        if (i != lru_index) {
            cache->array[i]->LRU++;
        } else {
            cache->array[i]->LRU = 0;
        }
    }
}





/*
 * Function for read-operation for write-through policy
 */
static void cache_wt_read(cache_t *cache, uint64_t address) {
    // Calculate index and descriptor from the address
    uint64_t addr_index = (address >> cache->offset_bitsize) & ((1 << cache->index_bitsize) - 1);
    uint64_t addr_descriptor = address >> (cache->offset_bitsize + cache->index_bitsize);

    // Calculate the start and end of the set
    int set_start = addr_index * cache->associativity;
    int set_end = set_start + cache->associativity;

    // Iterate over the cache lines in the set
    for (int i = set_start; i < set_end; i++) {
        if (cache->array[i]->index == addr_index) {
            // Find the highest LRU value
            int highest_lru_index = -1;
            for (int j = set_start; j < set_end; j++) {
                if (cache->array[j]->LRU == cache->associativity - 1) {
                    highest_lru_index = j;
                    break;
                }
            }

            // Update the cache line with the new address
            if (highest_lru_index != -1) {
                cache->array[highest_lru_index]->valid = 1;
                cache->array[highest_lru_index]->modified_bit = 0;
                cache->array[highest_lru_index]->descriptor = addr_descriptor;

                // Update all the LRU values in the set
                for (int j = set_start; j < set_end; j++) {
                    if (j != highest_lru_index) {
                        cache->array[j]->LRU++;
                    } else {
                        cache->array[j]->LRU = 0;
                    }
                }
            }
            break;
        }
    }
}






/*
 * Function checking if given address
 * exists in the cache.
 * Returns 1 if address is in cache and 0 if not.
 * If address exists we update the LRU values
 */
static int cache_contains(cache_t *cache, uint64_t address) {
    // Calculate index and descriptor from the address
    uint64_t addr_index = (address >> cache->offset_bitsize) & ((1 << cache->index_bitsize) - 1);
    uint64_t addr_descriptor = address >> (cache->offset_bitsize + cache->index_bitsize);

    // Calculate the start and end of the set
    int set_start = addr_index * cache->associativity;
    int set_end = set_start + cache->associativity;

    // Iterate over the cache lines in the set
    for (int i = set_start; i < set_end; i++) {
        if (cache->array[i]->valid && cache->array[i]->descriptor == addr_descriptor) {
            // Update LRU values
            for (int j = set_start; j < set_end; j++) {
                if (cache->array[j]->LRU < cache->array[i]->LRU) {
                    cache->array[j]->LRU++;
                }
            }
            cache->array[i]->LRU = 0; // Reset LRU of the accessed line
            return 1; // Cache hit
        }
    }

    return 0; // Cache miss
}




/*
 * Function for setting a modified_bit value to a block
 */
static void set_modified_bit(cache_t *cache, uint64_t address, int modified_bit) {
    // Calculate index and descriptor from the address
    uint64_t addr_index = (address >> cache->offset_bitsize) & ((1 << cache->index_bitsize) - 1);
    uint64_t addr_descriptor = address >> (cache->offset_bitsize + cache->index_bitsize);

    // Calculate the start and end of the set
    int set_start = addr_index * cache->associativity;
    int set_end = set_start + cache->associativity;

    // Iterate over the cache lines in the set
    for (int i = set_start; i < set_end; i++) {
        if (cache->array[i]->index == addr_index && cache->array[i]->descriptor == addr_descriptor) {
            // Set the modified bit to the new value
            cache->array[i]->modified_bit = modified_bit;
            return;
        }
    }
}


/*
 * Function for adding new address into cache when
 * a miss has occured, using write-back
 */

static void cache_add(cache_t *cache, uint64_t address) {
    // Calculate index and descriptor from the address
    uint64_t addr_index = (address >> cache->offset_bitsize) & ((1 << cache->index_bitsize) - 1);
    uint64_t addr_descriptor = address >> (cache->offset_bitsize + cache->index_bitsize);

    // Calculate the start and end of the set
    int set_start = addr_index * cache->associativity;
    int set_end = set_start + cache->associativity;

    // Find the least recently used (LRU) line in the set
    int lru_index = set_start;
    for (int i = set_start; i < set_end; i++) {
        if (cache->array[i]->LRU == cache->associativity - 1) {
            lru_index = i;
            break;
        }
    }

    // Update the cache line with the new address
    if (cache->array[lru_index]->modified_bit == 0) {
        cache->array[lru_index]->descriptor = addr_descriptor;
        cache->array[lru_index]->valid = 1;
        cache->array[lru_index]->modified_bit = 1;
    } else if (cache->array[lru_index]->modified_bit == 1 && cache->next != NULL) {
        uint64_t new_address = (cache->array[lru_index]->descriptor << (cache->offset_bitsize+cache->index_bitsize)) |
                               (addr_index << cache->offset_bitsize);
        cache_add(cache->next, new_address);
        cache->array[lru_index]->descriptor = addr_descriptor;
        cache->array[lru_index]->valid = 1;
        cache->array[lru_index]->modified_bit = 1;
    }

    // Update all the LRU values in the set
    for (int i = set_start; i < set_end; i++) {
        if (i != lru_index) {
            cache->array[i]->LRU++;
        } else {
            cache->array[i]->LRU = 0;
        }
    }
}



//checks if address is in cache and handle hits and misses
static int check_cache(cache_t *cache, uint64_t address) {
    if (cache_contains(cache, address)) {
        cache->hit++;
        return 1; // Cache hit
    } else {
        cache->miss++;
        return 0; // Cache miss
    }
}

//handles cache misses based on write policy
static void handle_cache_miss(cache_t *cache, uint64_t address) {
    if (cache->policy == 1) { // Write-back policy
        cache_add(cache, address);
        set_modified_bit(cache, address, 0);
    } else { // Write-through policy
        cache_wt_read(cache, address);
    }
}







// Write address from trace file into cache
void memory_write(uint64_t address, data_t *data) {
    printf("memory: write 0x%08lx\n", address);

    // Check L1 data cache
    if (check_cache(cache_one_data, address)) {
        if (cache_one_data->policy == 1) { // Write-back policy
            cache_add(cache_one_data, address);
            set_modified_bit(cache_one_data, address, 1);
        }
    } else {
        if (cache_one_data->policy == 1) { // Write-back policy
            cache_add(cache_one_data, address);
            set_modified_bit(cache_one_data, address, 1);
        } else { // Write-through policy
            cache_wt_write(cache_one_data, address);
        }
    }

    instruction_count++;
}


// Fetch addresses from trace file
void memory_fetch(uint64_t address, data_t *data) {
    printf("memory: fetch 0x%08lx\n", address);

    // Check L1 instruction cache
    if (!check_cache(cache_one_intruction, address)) {
        handle_cache_miss(cache_one_intruction, address);

        // Check L2 cache if address was not found in L1
        if (!check_cache(cache_two, address)) {
            handle_cache_miss(cache_two, address);
        }
    }

    instruction_count++;
}



/* Read addresses from trace file */
void memory_read(uint64_t address, data_t *data) {
    printf("memory: read 0x%08lx\n", address);

    // Check L1 data cache
    if (!check_cache(cache_one_data, address)) {
        handle_cache_miss(cache_one_data, address);

        // Check L2 cache if address was not found in L1
        if (!check_cache(cache_two, address)) {
            handle_cache_miss(cache_two, address);
        }
    }

    instruction_count++;
}



// Deallocate memory for cache

static void cache_destroy(cache_t *cache) {
    if (cache == NULL) {
        return;
    }

    // Free memory allocated for the structure in each array element
    for (int i = 0; i < cache->index_sets * cache->associativity; i++) {
        free(cache->array[i]);
    }

    // Free the memory allocated for the array and the cache itself
    free(cache->array);
    free(cache);
}



/* Deinitialize memory subsystem */
void memory_finish(void) {
    fprintf(stdout, "Executed %lu instructions.\n\n", instruction_count);

    // Calculate hit rates
    uint64_t instruction_miss = cache_one_intruction->hit + cache_one_intruction->miss;
    uint64_t data_miss = cache_one_data->hit + cache_one_data->miss;
    uint64_t l2_miss = cache_two->hit + cache_two->miss;

    double hit_ins = (instruction_miss > 0) ? ((double)cache_one_intruction->hit / instruction_miss) * 100 : 0.0;
    double hit_data = (data_miss > 0) ? ((double)cache_one_data->hit / data_miss) * 100 : 0.0;
    double hit_two = (l2_miss > 0) ? ((double)cache_two->hit / l2_miss) * 100 : 0.0;

    // Output results
    fprintf(stdout, "Hitrate level one instruction cache: %lu of %lu instructions; %.2f%%\n", cache_one_intruction->hit, instruction_miss, hit_ins);
    fprintf(stdout, "Hitrate level one data cache: %lu of %lu instructions; %.2f%%\n", cache_one_data->hit, data_miss, hit_data);
    fprintf(stdout, "Hitrate level two cache: %lu of %lu instructions; %.2f%%\n", cache_two->hit, l2_miss, hit_two);

    // Deallocate memory that was allocated
    cache_destroy(cache_one_intruction);
    cache_destroy(cache_one_data);
    cache_destroy(cache_two);
}
