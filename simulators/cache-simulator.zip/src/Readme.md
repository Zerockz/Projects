to create the executable cachesim you use the make command.



you then run the traceconverter on the logfile: example: >python3 traceconverter.py




for changes in parameters you can use the memory.c file

trace2.tr is the test file
